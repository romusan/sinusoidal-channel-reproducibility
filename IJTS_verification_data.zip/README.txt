Verification of conjugate heat transfer in a sinusoidal air channel
Verification dataset for the IJTS manuscript

The paper's paired comparisons use A = 1.50 mm, H = 15 mm and W = 300 mm.
S1 contains Re0 = 100, wavelength 60 mm; S2 contains Re0 = 800, wavelength 30 mm;
S3 contains Re0 = 800, wavelength 60 mm; S4 contains Re0 = 800 minus Re0 = 100 at
the same 60 mm wavelength. The signs of changes are defined relative to the
flat duct for the same grid, Reynolds number and lateral treatment. h is based
on actual heated area. Static pressure drop is between x = -60 and +360 mm.
Sensitivity rows labelled first_ring use the expanded correction stencil. S3
and S1 include medium and fine variants, and S4 pairs both variants across Reynolds numbers.
S5 contains the transient summaries and S6 the time series. S7 contains the 60 mm
results on the mesh family shared with the 30 mm wave. S8 through S10 contain
the extended four-grid paired results, sampled sensitivities, and case-level data.

The study folder contains the case-level quantities, benchmark results, residual
histories, flow configuration files and analysis code for the reported numerical
checks. Mesh cell and node arrays, full velocity and temperature fields, and
native CAD files remain in the project archive. The audit scripts can be used
with this bundle without those fields. Re-running the CFD requires the project
meshes or their regeneration, solver restart data, and SU2 v8.6.0.
The 3D solver provenance and run commands are documented in the study README.
No experimental measurements are included.

To regenerate the matched 60 mm summaries, install NumPy, pandas, SciPy, and
scikit-fem 12.0.2; then run from the extracted directory:
    python 07_estudio_3d/comparar_contornos_re100.py --re 100 --fine-sensitivity
    python 07_estudio_3d/comparar_contornos_re100.py --re 800 --fine-sensitivity
    python 07_estudio_3d/comparar_l60_pared.py --from-csv 07_estudio_3d/resultados_l60_pared.csv
