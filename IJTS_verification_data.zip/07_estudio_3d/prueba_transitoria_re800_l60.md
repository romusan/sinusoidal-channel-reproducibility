# Perturbaciones 3D a Reynolds 800 y longitud de onda de 60 mm

Las cuatro integraciones parten de los campos estacionarios convergidos del canal plano y del ondulado de amplitud 1,50 mm. La perturbación inicial del plano transversal tiene amplitud máxima de 0,01 veces la velocidad de referencia y longitud de onda nominal de cuatro alturas. La integración BDF2 usa la malla de 16.128 celdas, Δt U₀/H = 0,50 y diez iteraciones internas por paso. Se registran dos tránsitos de ducto completo. Se integra el momento de propiedades constantes. La energía es pasiva en este modelo.

| Canal | Laterales | RMS final / RMS inicial | Pico en último cuarto / RMS inicial | RMS final respecto al control / RMS inicial |
| --- | --- | ---: | ---: | ---: |
| Plano | Sólidos | 0,01294 | 0,01311 | 0,00139 |
| Onda de 60 mm | Sólidos | 0,00931 | 0,00977 | 0,00097 |
| Plano | Periódicos | 0,07900 | 0,07903 | 0,00023 |
| Onda de 60 mm | Periódicos | 0,08257 | 0,08262 | 0,00032 |

Para cada caso, la trayectoria de control parte del campo estacionario sin perturbación. Usa el mismo paso y malla y permite terminar las iteraciones internas al alcanzar el criterio residual. La diferencia sembrado–control mide la perturbación respecto a la trayectoria sin semilla. El comportamiento se limita a la perturbación, ventana y anchura ensayadas.

| Laterales de la onda | RMS a 1,5 tránsitos / inicial con Δt U₀/H = 0,50 | RMS a 1,5 tránsitos / inicial con Δt U₀/H = 0,25 |
| --- | ---: | ---: |
| Sólidos | 0,00240 | 0,00239 |
| Periódicos | 0,02571 | 0,02584 |

La prueba de paso temporal cubre 1,5 tránsitos en la malla de 3.600 celdas. Los dos pasos usan hasta diez iteraciones internas con comprobación residual a partir de la tercera.

## Comparación estacionaria en la familia común de mallas

Los casos de 60 mm y 30 mm usan las mismas particiones axial, vertical y transversal y el mismo estiramiento. Se reutilizaron los controles planos de esa familia. La primera capa junto al absorbedor, en el caso ondulado de 60 mm, pasa de 1,17–1,43 mm en la malla fina del contraste de Reynolds a 0,73–0,89 mm en la malla fina común.

| Malla | Celdas de aire | Δh sólidos | Δh periódicos | Δp sólidos | Δp periódicos |
| --- | ---: | ---: | ---: | ---: | ---: |
| Gruesa | 7.776 | −1,587 % | −2,750 % | +10,164 % | +10,407 % |
| Media | 26.244 | −1,789 % | −1,804 % | +8,872 % | +9,017 % |
| Fina | 91.854 | −2,423 % | −2,401 % | +8,476 % | +8,611 % |

[Resumen transitorio](transitorios_re800_l60.csv) · [Series](series_transitorias_re800_l60.csv) · [Comparación de mallas](comparacion_re800_l60_malla_comun.csv) · [Valores por caso en la familia común](resultados_re800_l60_malla_comun.csv)

Las configuraciones y los historiales están en transitorios/re800_l60. El script refinar_re800_l60.py reproduce la familia común. El script resumir_transitorios_re800.py valida el último paso, verifica la coincidencia de las caras periódicas y extrae las métricas de los campos guardados.
