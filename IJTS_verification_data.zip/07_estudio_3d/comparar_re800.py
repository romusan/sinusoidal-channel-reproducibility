"""Check and compare the three matched forced-convection pairs."""

import numpy as np
import pandas as pd

from flujo_re800 import CASES, GRIDS, HERE, ROOT


def main():
    full = pd.concat([pd.read_csv(HERE / f're800_cht_{grid}.csv') for grid in GRIDS], ignore_index=True)
    graetz = pd.concat([pd.read_csv(HERE / 're800_graetz_acotado.csv').query('malla != "fina"'),
                        pd.read_csv(HERE / 're800_graetz_fina.csv')], ignore_index=True)
    ref = pd.read_csv(HERE / 'benchmark_rectangular_3d.csv').set_index('Re_ref').loc[800.]
    assert len(full) == 6 and len(graetz) == 3
    assert full.Re_ref.eq(800.).all() and graetz.Re_ref.eq(800.).all()
    assert set(full.malla) == set(graetz.malla) == set(GRIDS)
    assert all(set(group.caso) == set(CASES) for _, group in full.groupby('malla'))
    checks = pd.concat([full, graetz], ignore_index=True)
    assert (checks.min_temperature_K >= 300. - checks.bound_tolerance_K).all()
    assert (checks.max_air_minus_wall_K <= checks.bound_tolerance_K).all()
    assert checks.Q1_residual_relative.abs().max() < 2e-8
    assert checks.cierre_energia_rel.abs().max() < 1e-7
    assert full.error_masa_rel.abs().max() < .005
    assert full.max_error_flujo_seccional_rel.abs().max() < .015
    assert (full.Re_ref_entrada - 800.).abs().max() < .5
    graetz = graetz.set_index('malla')
    pairs = []
    for grid in GRIDS:
        block = full[full.malla.eq(grid)].set_index('caso')
        flat, wave = (block.loc[c] for c in CASES)
        assert flat.celdas_aire == wave.celdas_aire == graetz.loc[grid].celdas_aire
        residuals = []
        for case in CASES:
            path = ROOT / grid / (case + '_Re800')
            last = pd.read_csv(path/'history_air.csv').iloc[-1]
            residuals.append(max(float(last[key]) for key in last.index if 'rms[' in key))
        pairs.append(dict(
            malla=grid, celdas_aire=int(flat.celdas_aire), celdas_placa=int(flat.celdas_placa),
            h_plano_W_m2K=flat.h_W_m2K, h_onda_W_m2K=wave.h_W_m2K,
            cambio_h_pct=100*(wave.h_W_m2K/flat.h_W_m2K - 1),
            dp_plano_Pa=flat.dp_Pa, dp_onda_Pa=wave.dp_Pa,
            cambio_dp_pct=100*(wave.dp_Pa/flat.dp_Pa-1),
            error_presion_plana_pct=100*flat.error_dp_rect_rel,
            h_Graetz_W_m2K=graetz.loc[grid].h_W_m2K,
            error_Graetz_pct=100*(graetz.loc[grid].h_W_m2K/ref.h_Graetz_3D_W_m2K-1),
            log10_rms_flujo_plano=residuals[0], log10_rms_flujo_onda=residuals[1],
        ))
    result = pd.DataFrame(pairs)
    result.to_csv(HERE / 'comparacion_re800_acotada.csv', index=False, encoding='utf-8-sig')
    full.to_csv(HERE / 'resultados_re800_acotados.csv', index=False, encoding='utf-8-sig')
    values = result.cambio_h_pct.to_numpy()
    spread = 1.25*np.ptp(values)
    print(result.to_string(index=False, float_format=lambda x: f'{x:.6f}'))
    print(f'Consistent sign: {np.all(np.sign(values) == np.sign(values[-1]))}. '
          f'Paired mesh spread x 1.25: {spread:.5f} percentage points. '
          f'Fine minus medium: {values[-1]-values[-2]:.5f} percentage points.')
    print(f'Maximum relative energy imbalance: {checks.cierre_energia_rel.abs().max():.2e}. '
          f'Maximum relative sectional mass deviation: {full.max_error_flujo_seccional_rel.abs().max():.2e}.')


if __name__ == '__main__':
    main()
