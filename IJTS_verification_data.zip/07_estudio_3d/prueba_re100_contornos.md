# Periodicidad transversal a Reynolds 100

Se compara el canal plano con el ondulado de semiamplitud 1,50 mm y longitud de onda 60 mm. Ambos tienen un ancho de 300 mm y una altura media de 15 mm. Se aplican 100 W/m² de área proyectada, equivalentes a 9 W en cada geometría. El caudal nominal corresponde a Re₀ = 100 con el mismo diámetro hidráulico de referencia en ambos contornos. Las tomas de presión estática están en x = −60 y 360 mm.

| Malla | Divisiones en tramo caliente, altura y ancho | Celdas de aire | Celdas de placa |
| --- | ---: | ---: | ---: |
| Gruesa | 40 × 5 × 10 | 3.600 | 400 |
| Media | 80 × 7 × 16 | 16.128 | 2.560 |
| Fina | 120 × 9 × 22 | 42.768 | 7.920 |

Se reutilizan los seis campos de momento convergidos de la campaña a Re₀ = 100 con laterales sólidos. La temperatura es pasiva en el modelo forzado de propiedades constantes, por lo que los campos son compatibles con el nuevo tratamiento térmico. Se vuelven a calcular las seis soluciones de energía con laterales sólidos y se resuelven seis casos nuevos de momento y energía con periodicidad transversal.

Las corridas periódicas de SU2 8.6.0 emparejan las caras en z = 0 y 300 mm. Cada par con contorno sólido y periódico comparte coordenadas, conectividad y archivo de entrada. El perfil de velocidad rectangular es común y conserva su variación transversal a la entrada. El problema mantiene la entrada y salida axial, el techo y piso sin deslizamiento y las condiciones de calentamiento. [Comparación a Reynolds 800](prueba_re800_contornos.md)

La ecuación de energía conjugada Q1 usa la corrección local conservativa con σ = 0 y comprobación a posteriori de las cotas a 10⁻⁶ K. En los casos periódicos se identifican los nodos opuestos tanto en aire como en placa antes de aplicar la corrección. Se compara la solución principal con una variante en malla media y fina que incorpora los vecinos inmediatos de los nodos infractores desde la primera corrección. En cada malla y contorno, el cambio se calcula como 100 × (valor ondulado / valor plano − 1). El coeficiente h se refiere al área real del absorbedor.

## Resultados

| Malla | Celdas de aire | Cambio en h con laterales sólidos | Cambio en h con periodicidad | Cambio en Δp con laterales sólidos | Cambio en Δp con periodicidad |
| --- | ---: | ---: | ---: | ---: | ---: |
| Gruesa | 3.600 | +0,233 % | +0,276 % | +3,831 % | +3,789 % |
| Media | 16.128 | +0,464 % | +0,485 % | +3,753 % | +3,729 % |
| Fina | 42.768 | +0,429 % | +0,451 % | +3,764 % | +3,729 % |

| Geometría en malla fina | h sólido [W/(m² K)] | h periódico [W/(m² K)] | Δp sólido [Pa] | Δp periódico [Pa] |
| --- | ---: | ---: | ---: | ---: |
| Plana | 4,93240 | 4,97323 | 0,023901 | 0,022992 |
| Ondulada | 4,95355 | 4,99565 | 0,024801 | 0,023849 |

El aumento de h se mantiene con ambos contornos en las tres mallas. El stencil ampliado da +0,397 % con laterales sólidos y +0,411 % con periodicidad en malla media, y +0,355 % y +0,407 % en malla fina. Con 1,25 veces el rango entre mallas más el mayor cambio por stencil en las mallas media y fina, las sensibilidades descriptivas son 0,362 y 0,336 puntos porcentuales. La magnitud del contraste lateral de la solución base en malla fina es 0,022 puntos porcentuales, dentro de su sensibilidad de 0,057 puntos.

La periodicidad reduce la caída de presión absoluta en todas las mallas. En malla fina, la caída se reduce un 3,80 % para el canal plano y un 3,84 % para el ondulado. Dentro de cada contorno, la ondulación aumenta la caída de presión en torno al 3,7–3,8 %.

El logaritmo en base 10 del residuo RMS de presión es ≤ −11 en los doce campos de momento usados. Los campos térmicos cumplen las cotas especificadas y las caras emparejadas coinciden en los valores archivados de presión, velocidad y temperatura. En el cálculo principal, el mayor error de cierre energético relativo es 3,58 × 10⁻¹¹, la desviación seccional de caudal máxima es 0,522 % y la mayor diferencia de Re₀ de entrada entre contornos es 0,031. El alcance es convección forzada estacionaria con calentamiento prescrito. La flotación, que puede importar a este Reynolds, queda fuera de este contraste. El [contraste a longitud de onda fija](prueba_re800_l60_contornos.md) compara los mismos canales a 100 y 800. [Comparación](comparacion_contornos_re100.csv) · [Resultados por caso](resultados_re100_contornos.csv) · [Variante en malla media](re100_contornos_sensibilidad_acotada.csv) · [Variante en malla fina](re100_contornos_sensibilidad_acotada_fina.csv)

## Reproducción

Desde esta carpeta, con Python, SciPy, NumPy, pandas, scikit-fem y SU2 en el entorno de la [campaña 3D](README.md). Se leen los controles de `corridas/gruesas`, `corridas/campana` y `corridas/refinadas`. El archivo de entrada, la configuración periódica, los historiales y los campos nuevos se archivan en `corridas/prueba_re100_periodica`.

```powershell
python prueba_re100_contornos.py --out resultados_re100_contornos.csv
python prueba_re100_contornos.py --mallas media --workers 1 --first-ring --out re100_contornos_sensibilidad_acotada.csv
python prueba_re100_contornos.py --mallas fina --workers 1 --first-ring --out re100_contornos_sensibilidad_acotada_fina.csv
python comparar_contornos_re100.py --fine-sensitivity
```
