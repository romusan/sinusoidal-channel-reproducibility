"""Create the technical report from the completed 3D campaign tables."""

from pathlib import Path
import os

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


HERE = Path(__file__).resolve().parent
FONTS = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
pdfmetrics.registerFont(TTFont("Study", str(FONTS/"arial.ttf")))
pdfmetrics.registerFont(TTFont("StudyBold", str(FONTS/"arialbd.ttf")))
pdfmetrics.registerFontFamily("Study", normal="Study", bold="StudyBold")
NAVY = colors.HexColor("#132b40")
TEAL = colors.HexColor("#096d6e")
GRAY = colors.HexColor("#46576a")


def f(value, places=3):
    return f"{value:.{places}f}".replace(".", ",")


def delta(value, places=2):
    return f(100*(value-1), places)


def read(name):
    path = HERE / f"{name}.csv"
    return pd.read_csv(path) if path.is_file() else pd.DataFrame()


def footer(canvas, doc):
    canvas.setFont("Study", 8)
    canvas.setFillColor(GRAY)
    canvas.setStrokeColor(colors.HexColor("#bdced3"))
    canvas.line(45, 44, A4[0]-45, 44)
    canvas.drawString(45, 30, "PANEL SINUSOIDAL  /  EXPERIMENTO TRIDIMENSIONAL")
    canvas.drawRightString(A4[0]-45, 30, str(doc.page))


def main():
    grid = read("resultados_3d")
    pairs = read("comparacion_pareada_3d")
    ref = read("refinamiento_3d")
    trans = read("transitorios_3d")
    pump = read("igual_potencia_3d")
    buoyancy = read("flotacion_3d")
    high_sensitivity = read("sensibilidad_alta_3d")
    graetz = read("contraste_graetz_q1")
    exact = read("benchmark_rectangular_3d").set_index("Re_ref")
    good = grid[grid.estado_balance.eq("aceptable")]
    medium = pairs[pairs.malla.eq("media")]
    labels = getSampleStyleSheet()
    for name, font, size, leading, after, color in (
        ("Lead", "StudyBold", 27, 30, 13, NAVY),
        ("Head", "StudyBold", 20, 23, 12, NAVY),
        ("Topic", "StudyBold", 11, 14, 6, TEAL),
        ("Tag", "StudyBold", 8.5, 11, 10, TEAL),
        ("Body", "Study", 10.4, 14, 8, NAVY),
        ("Small", "Study", 8.8, 11.6, 7, GRAY),
        ("Cell", "Study", 8, 10.5, 0, NAVY),
        ("CellHead", "StudyBold", 8, 10.5, 0, colors.white),
    ):
        labels.add(ParagraphStyle(name, fontName=font, fontSize=size, leading=leading,
                                  spaceAfter=after, textColor=color))
    story = []

    def p(text, style="Body"):
        story.append(Paragraph(text, labels[style]))

    def page(number, title):
        story.append(PageBreak())
        p(number, "Tag")
        p(title, "Head")

    def table(rows, widths):
        cells = [[Paragraph(str(value), labels["CellHead" if i == 0 else "Cell"])
                  for value in row] for i,row in enumerate(rows)]
        t = Table(cells, colWidths=widths, repeatRows=1, hAlign="LEFT")
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),NAVY),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#edf4f5")]),
            ("VALIGN",(0,0),(-1,-1),"TOP"),
            ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ]))
        story.extend([t, Spacer(1,9)])

    def figure(name, width):
        path = HERE/"figuras"/name
        if path.is_file():
            img = Image(str(path))
            img.drawHeight *= width/img.drawWidth
            img.drawWidth = width
            img.hAlign = "LEFT"
            story.append(img)

    p("INFORME TÉCNICO  /  12 DE NOVIEMBRE DE 2026", "Tag")
    p("Transferencia de calor en el panel sinusoidal tridimensional", "Lead")
    p("Comparación a ancho completo con la placa plana y el modelo 2D", "Topic")
    p(f"Se resolvieron {len(grid)} puntos estacionarios de flujo y transferencia conjugada "
      f"en el dominio tridimensional. {len(good)} cumplieron los diagnósticos combinados de "
      "temperatura y conservación definidos en el análisis. El conjunto incluye las "
      "referencias planas para cada altura y la familia paramétrica de absorbedores ondulados.")
    if not ref.empty:
        rows = [["Caso a Re = 100", "Δh fina [%]", "Sensibilidad numérica [pp]", "Δp fina [%]"]]
        for r in ref.itertuples():
            rows.append([r.caso.replace("_", " / "), delta(r.ratio_h_W_m2K_fina, 3),
                         f(r.U_h_combinada*100), delta(r.ratio_dp_Pa_fina)])
        table(rows,[175,93,130,96])
        if ref.mejora_h_resuelta.any():
            p("Los aumentos marcados como resueltos superan la sensibilidad numérica "
              "muestreada en esta campaña forzada. La comparación sigue condicionada al modelo de propiedades constantes.")
        else:
            p("En las comparaciones refinadas, el aumento del coeficiente queda dentro "
              "de la sensibilidad numérica muestreada o cambia de signo.")
        for r in pairs[(pairs.malla=="fina") & pairs.Re_ref_objetivo.eq(100)].itertuples():
            p(f"{r.caso.replace('_',' / ')}. Área real {delta(r.ratio_area_real_m2,3)} % "
              f"mayor y conductancia hA {delta(r.ratio_hA,3)} % mayor que en la plana.", "Small")
    if not good.empty:
        p(f"El calor útil de los casos que pasan los diagnósticos va de {f(good.Q_aire_W.min(), 5)} "
          f"a {f(good.Q_aire_W.max(), 5)} W. Los valores se interpretan bajo el aporte fijo "
          "de 9 W y las fronteras térmicas aisladas.")
    p("Qué aporta la formulación 3D", "Topic")
    p("El modelo incluye el gradiente transversal de velocidad y temperatura, la fricción "
      "en los laterales y la conducción a través del espesor y del ancho de la placa. "
      "La comparación con 2D mantiene la altura, la amplitud, la longitud de onda, el "
      "área proyectada y la definición del coeficiente.")
    figure("panel_parametrico_3d.png", 445)
    p("Dominio paramétrico del caso de onda larga y semi-amplitud de 1,50 mm. "
      "La altura se amplía gráficamente para distinguir el absorbedor.", "Small")

    page("01  /  GEOMETRÍA Y FORMULACIÓN", "Panel y condiciones de contorno")
    p("La misma tabla de parámetros gobierna el CAD y el generador de malla. Se emplean "
      "ancho W = 300 mm, longitud activa L = 300 mm y dos extensiones de 120 mm. "
      "El piso activo es y = A sen(2πx/λ), el techo está a y = H y los laterales "
      "en z = 0 y W. Las alturas son 12, 15 y 20 mm, las semi-amplitudes son 0, 0,75 y "
      "1,50 mm y las longitudes de onda son 30 y 60 mm. La placa tiene 1 mm de espesor vertical.")
    p("El flujo se calcula mediante continuidad y Navier–Stokes incompresible en las "
      "tres direcciones. SU2 8.6.0 usa volúmenes finitos centrados en vértices, flujo FDS, "
      "reconstrucción MUSCL y avance implícito en pseudotiempo. La entrada usa el perfil "
      "desarrollado rectangular normalizado al caudal objetivo. La salida fija presión "
      "estática de referencia. Aire a 300 K con ρ = 1,177 kg/m³, μ = 1,846 × 10⁻⁵ Pa s, "
      "k = 0,02624 W/(m K) y cₚ = 1006 J/(kg K).")
    p("Se resuelve ∇·(ρcₚuT − k∇T) = 0 en el aire y ∇·(kₛ∇T) = 0 en la placa con "
      "hexaedros Q1. kₛ = 205 W/(m K). La interfaz comparte temperatura y conserva flujo "
      "normal en forma débil. La carga posterior es 100 W/m² de área proyectada. La "
      "proyección de cada cara conserva el aporte de 9 W en el dominio discreto. "
      "Las demás paredes y los cantos de la placa están aislados.")
    p("El término direccional estabiliza la advección. Se añade difusión simétrica "
      "localizada si aparecen temperaturas inferiores a 299,97 K. Ambos términos "
      "conservan el balance global. El cálculo térmico de producción usa el campo de "
      "velocidad estacionario de SU2. La separación entre momento y energía es válida "
      "para las propiedades constantes sin flotación.")
    p("Fuentes y comparabilidad", "Topic")
    p('La revisión incorpora trabajos de 2020–2026. Harikrishnan y Tiwari estudiaron '
      'una pared sinusoidal con techo plano y la aparición de inestabilidad 3D. '
      'Gepner y Floryan muestran la dependencia de modos secundarios con la geometría '
      'y la longitud periódica. Pang y Wang examinan un ducto sinusoidal rectangular. '
      'Estos antecedentes no fijan el Reynolds crítico del presente panel. '
      '<link href="https://doi.org/10.1080/01457632.2021.1875167">Harikrishnan y Tiwari (2022)</link>. '
      '<link href="https://doi.org/10.1017/jfm.2023.719">Gepner y Floryan (2023)</link>. '
      '<link href="https://doi.org/10.1016/j.energy.2025.137939">Pang y Wang (2025)</link>.')
    p("La matriz bibliográfica conserva acceso, contornos, coincidencia geométrica "
      "y referencias utilizables para verificación. El perfil plano y el Graetz "
      "rectangular son pruebas independientes de los campos del panel.", "Small")

    page("02  /  VERIFICACIÓN", "Presión, energía y malla")
    p("La presión exacta del ducto plano se calcula de la serie de Poiseuille de "
      "aspecto finito. Se compara a igual caudal medido en la entrada y entre x = −60 "
      "y 360 mm. En Graetz se impone el perfil analítico y se aplica calor en una pared "
      "con las tres restantes aisladas. La prueba térmica elimina la difusión axial y "
      "la placa para reproducir las condiciones del banco independiente.")
    pressure_rows = [["Malla plana H = 15 mm", "Re", "Δp 3D [Pa]", "Δp exacta [Pa]", "Desv. [%]"]]
    flat = grid[(grid.A_mm == 0) & (grid.H_mm == 15) & grid.Re_ref_objetivo.isin([100,800])]
    for r in flat.sort_values(["Re_ref_objetivo","celdas_aire"]).itertuples():
        pressure_rows.append([r.malla, f(r.Re_ref_objetivo,0), f(r.dp_Pa,6),
                              f(r.dp_rect_exacto_Pa,6), f(100*r.error_dp_rect_rel,2)])
    table(pressure_rows,[150,56,94,103,91])
    therm_rows = [["Re", "h FEM 3D [W/(m² K)]", "h Graetz 3D [W/(m² K)]", "Desv. [%]"]]
    for re, g in graetz.groupby("Re_ref"):
        hval = g.iloc[-1].h_W_m2K
        hbase = exact.loc[re].h_Graetz_3D_W_m2K
        therm_rows.append([f(re,0),f(hval,5),f(hbase,5),f(100*(hval/hbase-1))])
    table(therm_rows,[65,145,164,120])
    p("Las mallas usan intervalos axiales, verticales y laterales distintos. La "
      "envolvente de 1,25 veces la amplitud de las tres razones pareadas mide sensibilidad "
      "a la malla. Se suma la diferencia absoluta entre las dos intensidades de estabilización "
      "ensayadas cuando existe esa comparación. La suma carece de interpretación probabilística "
      "y no cubre el error del modelo "
      "de propiedades constantes.")
    p("Los diagnósticos de producción comprueban balance de masa en entrada y salida, "
      "desviación del caudal entre secciones, balance global de energía y temperatura "
      "entre la entrada y el máximo de la placa. La etiqueta de revisión en el CSV "
      "identifica los casos que necesitan mayor refinamiento. La convergencia del balance "
      "no reemplaza una prueba de campo local.")
    if not good.empty:
        p(f"En los casos que superan los diagnósticos, el mayor desbalance de masa "
          f"entrada-salida fue {f(100*good.error_masa_rel.abs().max(),4)} % y el de energía "
          f"{good.cierre_energia_rel.abs().max():.2e} en valor relativo.", "Small")
    p("La corrida exploratoria SU2 multizona partió de campos térmicos uniformes y "
      "terminó con un desbalance importante en el caso plano de bajo Reynolds. Los "
      "resultados del informe proceden del cálculo conjugado Q1 y no de ese piloto.", "Small")

    page("03  /  RESULTADOS", "Coeficiente y caída de presión")
    figure("comparacion_2d_3d.png", 498)
    p("Figura 1. Cocientes de h y Δp frente a la placa plana de la misma altura. "
      "Las barras muestran malla 3D media. Los círculos provienen del cálculo 2D "
      "anterior. La trama indica revisión de campo o balance. A Re = 800 no se "
      "estimó la sensibilidad de malla de cada par.", "Small")
    p("h divide el flujo neto del absorbedor por el área sinusoidal y el promedio de "
      "T de pared menos T de mezcla local. Δp usa dos planos fijos. Las razones de h, "
      "Δp y Q se forman a igual Reynolds y altura. La potencia de bombeo usa la caída "
      "estática del ducto completo multiplicada por el caudal.")
    if not pump.empty:
        p("La tabla de potencia igualada utiliza interpolación PCHIP de Δp contra Re y "
          "una raíz acotada del producto presión–caudal. Su validez queda limitada "
          "a los puntos que encierran la potencia del plano.")
        for r in pump.itertuples():
            p(f"{r.caso.replace('_', ' / ')}. A {f(r.potencia_W*1000,5)} mW, el punto "
              f"interpolado es Re = {f(r.Re_ondulado,2)} y el cambio de h es "
              f"{delta(r.h_ratio,3)} %. Se trata de una estimación en malla media.", "Small")
    if len(high_sensitivity) == 2:
        a = high_sensitivity.sort_values("A_mm")
        h_alt = a.h_W_m2K.iloc[-1]/a.h_W_m2K.iloc[0]
        case = medium[(medium.caso=="H15_A150_L30") & medium.Re_ref_objetivo.eq(800)].iloc[0]
        p(f"En H15 / A1,50 / λ30 a Re = 800, el cambio de h pasó de "
          f"{delta(case.ratio_h_W_m2K)} % a {delta(h_alt)} % al quitar la difusión "
          "direccional global y conservar la corrección local. Esta sensibilidad "
          "limita la comparación cuantitativa en ese régimen.", "Small")

    page("04  /  CAMPOS Y ESTABILIDAD", "Efecto del ancho y perturbaciones")
    figure("campo_seccional_3d.png", 440)
    p("Figura 2. Corte de ancho completo. Los laterales modifican el campo térmico "
      "y permiten velocidades en la dirección transversal.", "Small")
    if not trans.empty:
        figure("decaimiento_3d.png", 430)
        p("Figura 3. Norma RMS de la diferencia de velocidad frente a la solución "
          "estacionaria. La pendiente de la curva depende de la malla, el paso y "
          "la perturbación. Un decaimiento finito no acota un Reynolds crítico.", "Small")
    if not buoyancy.empty:
        err = 100*buoyancy.cierre_energia_rel.abs().max()
        mass_err = 100*buoyancy.error_masa_rel.abs().max()
        if err < 1 and mass_err < .5 and len(buoyancy)==2:
            a = buoyancy.sort_values("A_mm")
            rel = a.h_W_m2K.iloc[-1]/a.h_W_m2K.iloc[0]
            p(f"Los dos pilotos Boussinesq en malla gruesa dan Δh = {delta(rel,3)} % "
              f"frente al plano, con desbalance de energía máximo de {f(err,3)} %. "
              "La comparación piloto necesita refinamiento y diagnóstico temporal.", "Small")
        else:
            p(f"Los pilotos Boussinesq llegaron a un desbalance máximo de energía "
              f"de {f(err,2)} % y de masa de {f(mass_err,2)} %. "
              "Además, produjeron temperaturas fuera de los límites físicos. "
              "Se conservan por trazabilidad y se excluyen de la conclusión cuantitativa.", "Small")
    p("Para H = 15 mm y Re = 100, gβ(qₚH/k)H/U² ≈ 3,46. La extrapolación del resultado "
      "forzado al colector requiere una evaluación 3D de flotación convergida. El inicio "
      "físico de la inestabilidad y la validación experimental del panel siguen abiertos.", "Small")
    doc = SimpleDocTemplate(str(HERE/"informe_3d.pdf"), pagesize=A4, leftMargin=45, rightMargin=45,
                            topMargin=46, bottomMargin=55,
                            title="Transferencia de calor en el panel sinusoidal tridimensional")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


if __name__ == "__main__":
    main()
