# Canal plano y ondulado a Reynolds 800 con energía acotada

La prueba compara dos conductos de 300 mm de ancho y altura media de 15 mm. El caso ondulado tiene semiamplitud de 1,50 mm y longitud de onda de 30 mm. Ambos tienen laterales sólidos sin deslizamiento, techo plano, una placa de 1 mm de espesor y 9 W aplicados por área proyectada. Se resuelve convección forzada estacionaria con propiedades constantes. El observable principal es el cambio porcentual de *h* respecto al canal plano. El coeficiente usa el área real analítica y la diferencia media entre la temperatura de la pared y la temperatura de mezcla del aire.

| Malla | Divisiones en tramo caliente, altura y ancho | Divisiones de placa en espesor | Celdas de aire | Celdas de placa |
| --- | ---: | ---: | ---: | ---: |
| Gruesa | 60 × 6 × 12 | 2 | 7.776 | 1.440 |
| Media | 90 × 9 × 18 | 3 | 26.244 | 4.860 |
| Fina | 135 × 14 × 27 | 4 | 91.854 | 14.580 |

El flujo se resuelve en SU2 8.6.0 con el mismo perfil rectangular de entrada, la misma presión de referencia en la salida y la misma formulación de momento en las seis corridas. Los campos archivados del estudio anterior sirven como estimación inicial interpolada. Cada corrida vuelve a resolver el momento en su propia malla. [Versión de SU2](https://github.com/su2code/SU2/releases/tag/v8.6.0)

La ecuación de energía Q1 conserva el flujo de entalpía y comparte la temperatura en la interfaz fluido–sólido. Se omite la difusión artificial global a lo largo de la corriente. La corrección local cancela los acoplamientos positivos fuera de la diagonal en el entorno de los nodos que infringen la cota de temperatura. Se añade difusión simétrica por aristas y se vuelve a resolver el sistema. La suma de las contribuciones añadidas por fila y columna es cero. El cálculo se acepta si la temperatura queda por encima de la entrada y el aire por debajo de la temperatura máxima de la interfaz, con tolerancia de 10⁻⁶ K. Se verifican también el residuo lineal y los balances. La comprobación de cotas es a posteriori para cada campo calculado. [Knobloch (2023)](https://doi.org/10.1007/s11075-023-01511-2) · [Knobloch et al. (2024)](https://doi.org/10.1016/j.jcp.2024.113305)

El banco térmico usa un perfil rectangular analítico, una pared calentada y conducción axial desactivada. A Re₀ = 800 la referencia modal de una pared da *h* = 7,267147 W/(m² K). La corrección local entrega 7,729350, 7,378269 y 7,287964 W/(m² K) en las mallas gruesa, media y fina. Las diferencias relativas son +6,36 %, +1,53 % y +0,29 %. Este contraste verifica el observable en el límite plano de Graetz. [Referencia modal local](referencia_rectangular.md) · [Graetz en ductos rectangulares](https://doi.org/10.1016/j.ijheatmasstransfer.2020.119846)

Un segundo contraste aísla la conducción conjugada. Se toma el tramo plano de 300 mm, con velocidad cero, techo a 300 K, 100 W/m² en el reverso de la placa y los demás contornos adiabáticos. La solución de Fourier es lineal en cada material, con salto de pendiente en la interfaz. El campo Q1 difiere de la solución analítica en un máximo de 1,31 × 10⁻⁹ K y el flujo integrado que sale por el techo es 9,0000000002 W. La comprobación verifica el ensamblaje de la interfaz en el caso plano.

En los sistemas grandes se usa eliminación directa por bloques de nodos que comparten una coordenada axial. Este cambio conserva la matriz térmica y las reglas de corrección. El contraste de los dos algoritmos de álgebra lineal sobre el sistema del canal ondulado en malla media dio una diferencia máxima de 2,71 × 10⁻¹⁰ K.

## Resultados

El cambio en *h* es negativo en las tres mallas. Los coeficientes están en W/(m² K). La caída de presión se mide entre x = −60 mm y x = 360 mm.

| Malla | *h* plano | *h* ondulado | Cambio de *h* | Cambio de caída de presión |
| --- | ---: | ---: | ---: | ---: |
| Gruesa | 7,6631 | 7,3373 | −4,25 % | +37,38 % |
| Media | 7,1766 | 6,7789 | −5,54 % | +23,35 % |
| Fina | 7,0180 | 6,6150 | −5,74 % | +17,16 % |

El cambio de *h* varía 0,20 puntos porcentuales entre la malla media y la fina. La amplitud total observada es 1,49 puntos, o 1,86 puntos al multiplicarla por 1,25. Este último valor expresa la dispersión muestreada y el margen adoptado. En la malla media, marcar también los vecinos de los nodos que infringen las cotas desde la primera pasada da −4,85 %, un desplazamiento de 0,69 puntos porcentuales respecto a la corrección principal. El signo se mantiene en esa variante. La caída de presión aumenta en las tres mallas y la magnitud de ese aumento es más sensible al refinamiento.

Las seis corridas alcanzaron el criterio de residuo de presión de SU2. Los campos térmicos cumplieron las cotas especificadas. El mayor desequilibrio térmico relativo fue 7,63 × 10⁻¹² y la mayor variación relativa de caudal por sección fue 0,589 %. El resultado se refiere a la solución estacionaria de convección forzada con laterales sólidos y a la geometría y carga indicadas. [Comparación pareada](comparacion_re800_acotada.csv) · [Resultados y controles de las seis corridas](resultados_re800_acotados.csv) · [Variante térmica en malla media](re800_cht_sensibilidad_acotada.csv)

## Reproducción

Desde `07_estudio_3d`, usar las mallas de `mallas/prueba_re800`, Python con NumPy, SciPy, pandas y scikit-fem 12.0.2, y SU2 con la ruta documentada en el [estudio 3D](README.md). Mantener un hilo por cálculo con `OMP_NUM_THREADS=1` y `OPENBLAS_NUM_THREADS=1`.

```powershell
python flujo_re800.py
python energia_acotada.py --graetz --mallas gruesa media --out re800_graetz_acotado.csv
python energia_acotada.py --graetz --mallas fina --out re800_graetz_fina.csv
python energia_acotada.py --mallas gruesa --out re800_cht_gruesa.csv
python energia_acotada.py --mallas media --out re800_cht_media.csv
python energia_acotada.py --mallas fina --out re800_cht_fina.csv
python energia_acotada.py --mallas media --first-ring --out re800_cht_sensibilidad_acotada.csv
python comparar_re800.py
```

Las configuraciones, historiales de residuos, campos y secciones están en `corridas/prueba_re800`. La [carpeta de bibliografía](../01_bibliografia/referencias_prioritarias_2020_2026/README.md) incluye las referencias descargadas y el registro de acceso.
