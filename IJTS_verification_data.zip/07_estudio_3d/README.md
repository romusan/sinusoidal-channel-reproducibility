# Experimento tridimensional del panel sinusoidal

El diseño usa la misma familia geométrica de nueve paneles del estudio anterior. Se resuelve el ancho completo de 300 mm con paredes laterales, techo y piso sin deslizamiento. Las coordenadas son X en el sentido del flujo, Y en altura y Z en ancho. El espesor vertical de la placa es 1 mm. Se mantienen los tramos rectos de 120 mm y los 9 W impuestos por área proyectada. El coeficiente se refiere al área de la sinusoide analítica.

| Archivo | Contenido |
| --- | --- |
| [Referencias y formulación 3D](referencias_3d.md) | Fuentes existentes y adicionales, búsqueda 2020–2026 y bancos de contraste |
| [Geometría y mallas](GEOMETRIA_Y_MALLA.md) | Panel paramétrico, interfaz, marcadores, unidades y correspondencia CAD |
| [Control de mallas](verificacion_mallas.jsonl) y [control de las gruesas](verificacion_mallas_gruesas.jsonl) | 17 verificaciones de contorno, interfaz coincidente y Jacobianos positivos |
| [Referencia independiente](referencia_rectangular.md) | Presión exacta y solución térmica de Graetz con ancho finito |
| [Resultados](resultados_3d.csv) | Reynolds, masa, temperatura, h, Nu, caída de presión, Darcy y potencia por caso |
| [Comparaciones con placa plana y 2D](comparacion_pareada_3d.csv) | Cocientes de h, caída de presión y calor útil por altura, malla y Reynolds |
| [Sensibilidad de malla](refinamiento_3d.csv) | Razones pareadas y amplitud de la dispersión en tres mallas |
| [Potencia igualada](igual_potencia_3d.csv) | Comparación interpolada en la ventana de bajo Reynolds |
| [Perturbaciones tridimensionales](transitorios_3d.csv) | Evolución de perturbaciones espaciales y tamaño de paso ensayado |
| [Pilotos de flotación](flotacion_3d.csv) | Corridas Boussinesq con campos no físicos, excluidas de la comparación cuantitativa |
| [Informe técnico](informe_3d.pdf) | Métodos, verificaciones, resultados y alcance |
| [Prueba a Reynolds 800 con energía acotada](prueba_re800_acotada.md) | Comparación pareada plano–ondulado y bancos de verificación |
| [Periodicidad transversal a Reynolds 800](prueba_re800_contornos.md) | Comparación térmica e hidráulica con laterales sólidos en las tres mallas |
| [Periodicidad transversal a Reynolds 100](prueba_re100_contornos.md) | Comparación con energía acotada para la onda de 60 mm y su control plano |
| [Contraste de Reynolds a 60 mm](prueba_re800_l60_contornos.md) | Plano y onda a Reynolds 100 y 800 con tres mallas y ambos contornos laterales |
| [Perturbaciones 3D a Reynolds 800](prueba_transitoria_re800_l60.md) | Plano y onda, laterales sólidos y periódicos, y comparación estacionaria en la familia común |
| [Cuarta malla cerca del absorbedor](prueba_l60_pared.md) | Comparación de Reynolds a longitud de onda fija con dos stencils y cuatro mallas comunes |

## Formulación y consistencia

Para convección forzada de propiedades constantes, el flujo se resuelve en SU2 8.6.0 mediante Navier–Stokes incompresible, volúmenes finitos centrados en vértices, separación de flujo FDS con reconstrucción MUSCL y pseudotiempo implícito. La entrada utiliza la serie de Poiseuille rectangular, normalizada para que su integral discreta coincida con el caudal prescrito. La salida fija la presión estática de referencia. El cálculo térmico usa los tres componentes de velocidad y resuelve la energía conjugada mediante elementos hexaédricos Q1. Las temperaturas comparten nodos en la interfaz aire–placa. Se conserva la forma de divergencia del flujo de entalpía, incluyendo el término advectivo de salida. La temperatura no retroalimenta al flujo en el modelo de propiedades constantes.

La estabilización direccional Q1 usa difusión a lo largo de la velocidad con factor 0,5 por longitud de celda axial. Una corrección algebraica localizada cancela acoples fuera de la diagonal positivos cerca de nodos que caen más de 0,03 K por debajo de la temperatura de entrada. Las contribuciones añadidas son simétricas y suman cero, de modo que se conserva el balance global. El archivo de resultados registra cuántos nodos activaron esta corrección. El contraste aislado de Graetz usa un perfil analítico y desactiva conducción axial y estabilización. La precisión de ese contraste verifica el cálculo de referencia plano bajo esas condiciones, con un alcance distinto al caso conjugado.

El Reynolds común usa el diámetro hidráulico del ducto plano de 15 mm. El diámetro de cada geometría se calcula con volumen y área mojada analítica en la zona activa. La caída de presión principal usa las tomas de x = −60 y 360 mm. Para igualar potencia se usa la caída de presión estática en todo el ducto. Las tablas incluyen también la diferencia de presión total con energía cinética ponderada por caudal. El promedio de temperatura del aire usa mezcla por entalpía y el promedio de diferencia térmica usa el área real del panel.

## Reproducción

Instalar NumPy, SciPy, pandas, matplotlib y scikit-fem 12.0.2 en Python de 64 bits. Obtener [SU2 v8.6.0 para Windows OpenMP](https://github.com/su2code/SU2/releases/tag/v8.6.0). El archivo empleado fue `SU2_v8.6.0_win64-omp.zip`, SHA-256 `4bc28b656def415b4d22c8274af2473dd719aa5ebfa6bc1c95c08b1bac26508c`. `su2_caso.py` admite `--su2` con la ruta al ejecutable. El orquestador usa de forma predeterminada `%TEMP%/colector_su2_860/bin/SU2_CFD.exe`.

Los comandos se ejecutan desde esta carpeta. La tabla de parámetros geométricos procede de `../02_cad/parametros.csv`.

```powershell
python referencia_rectangular.py
python campana_su2.py --grid mallas/campana --re 100 800 --output corridas/campana --iterations 500 --cfl 50
python campana_su2.py --grid mallas/refinadas --re 100 --output corridas/refinadas --workers 1 --iterations 650 --cfl 50
python campana_su2.py --grid mallas/gruesas --re 100 --output corridas/gruesas --workers 1 --iterations 430 --cfl 50
python campana_su2.py --grid mallas/campana --cases H15_Plana H15_A075_L60 H15_A150_L60 --re 75 125 --output corridas/ventana --from-directory corridas/campana --from-re 100 --workers 1 --iterations 225 --cfl 55
python energia_q1.py corridas/campana --sigma .5 --monotone --reuse --out cht_campana.csv
python energia_q1.py corridas/gruesas corridas/refinadas corridas/ventana --sigma .5 --monotone --reuse --out cht_sensibilidad.csv
python transitorio_su2.py corridas/gruesas/H15_A150_L60_Re100 --out transitorios/H15_A150_L60_Re100_dt05 --transits 1 --dt-star .5 --sample 12 --inner 5
python transitorio_su2.py corridas/gruesas/H15_A150_L60_Re100 --out transitorios/H15_A150_L60_Re100_dt025 --transits 1 --dt-star .25 --sample 24 --inner 5
python resumen_3d.py
```

Cada corrida conserva `case.json`, el archivo de configuración SU2, la historia residual y el campo de velocidades y presión. Los campos térmicos 3D se guardan en `termico_3d_q1.npz` con orden nodal del archivo estructurado de la malla. La sección por x se guarda en `secciones_cht_q1.csv`. Los casos de prueba SU2 multizona se conservan por trazabilidad y el informe distingue su balance del resultado térmico Q1.

Los pilotos de flotación usan `su2_boussinesq.py` con `--gravity --iterations 260`, las soluciones Q1 de la malla gruesa como semilla, y `medir_su2.py corridas/flotacion --out flotacion_3d.csv` para el diagnóstico. La rotación propia (x, y, z) → (x, −z, y) alinea la gravedad de SU2, que apunta en la última coordenada negativa, con el sentido de altura física. Las dos ejecuciones llegaron al límite de iteraciones con campos fuera de los límites de temperatura y sin cierre de masa o energía.
