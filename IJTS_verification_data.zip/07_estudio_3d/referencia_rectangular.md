# Verificación del ducto plano tridimensional

El cálculo independiente se reproduce desde esta carpeta con `python referencia_rectangular.py`. Requiere NumPy y SciPy. Genera `benchmark_rectangular_3d.csv`, `graetz_3d_estaciones.csv` y `perfil_desarrollado_3d.csv`. Se pueden variar las dimensiones, el flujo térmico, Reynolds, la distancia entre tomas y la longitud total. El Reynolds de referencia usa por defecto $D_{\rm ref}=28.57143$ mm aunque se cambie la altura física.

## Perfil de entrada y caída de presión

Con $y$ desde la pared que se calienta, $z$ desde un lateral, $\eta=y/H$, $s=z/W$ y $\beta=H/W$, el perfil desarrollado exacto es

$$
\frac{u(\eta,s)}{U}
=\frac{6}{C_\beta}\left[
\eta(1-\eta)-\sum_{j=1,3,5,\ldots}\frac{8\sin(j\pi\eta)}{(j\pi)^3}
\frac{\cosh[j\pi(s-\tfrac12)/\beta]}{\cosh[j\pi/(2\beta)]}
\right],
\qquad
C_\beta=1-\frac{192\beta}{\pi^5}
\sum_{j=1,3,5,\ldots}\frac{\tanh[j\pi/(2\beta)]}{j^5}.
$$

El gradiente de presión estática es $-dp/dx=12\mu U/(H^2 C_\beta)$, con $f_DRe_{D_h}=24(D_h/H)^2/C_\beta$ y $D_h=2WH/(W+H)$. Para $W/H=20$, $C_\beta=0.9684875562$, $u_{\rm centro}/U=1.54880668$, y la caída de presión a igual $U$ y longitud aumenta 3.254 % frente a placas paralelas. Una cuadratura de Gauss de 96 puntos por dirección recuperó $U$ con discrepancia relativa de $4.4\times10^{-12}$. El perfil se anula en las cuatro paredes y respeta la reflexión en ambos ejes centrales. La función `rectangular_velocity_profile(y,z,height,width,speed)` puede evaluarse sobre los nodos o centros de cara de la malla CFD. Para una entrada discreta, comprobar el caudal de los pesos que emplea el solver y, si es necesario, multiplicar el perfil por el cociente entre el caudal objetivo y el obtenido. [Solución de Poiseuille rectangular](https://doi.org/10.1016/0735-1933(94)90046-9).

Para una entrada uniforme, el perfil de velocidad y la presión se desarrollan en $x$. Calcular el error de perfil en la sección donde empieza el calentamiento y también en las tomas de presión. Para contrastar Poiseuille, usar el gradiente ajustado entre secciones donde el perfil y la pendiente de presión ya sean desarrollados. La caída entre las tomas fijas con perfil en desarrollo incluye la pérdida adicional de entrada. El caso de validación térmica con entrada uniforme requiere modelar el desarrollo hidrodinámico simultáneo, o alargar el tramo sin calentar hasta comprobar un perfil desarrollado. El umbral convencional de velocidad central al 99 % puede usarse como orientación y se complementa con un error integral sobre la sección completa. [Estudio de entrada hidrodinámica rectangular](https://doi.org/10.3390/fluids6070240).

## Graetz térmico de ancho finito

La referencia impone flujo uniforme $q''$ en la pared plana $y=0$ para $0<x<L$, con las demás paredes adiabáticas y temperatura uniforme al inicio del calentamiento. Considera aire de propiedades constantes, velocidad desarrollada y difusión transversal en $y,z$. En unidades $\theta=(T-T_{\rm in})/(q''H/k)$ y $\xi=kx/(\rho c_p U H^2)$, se resuelve

$$
(u/U)\,\partial_\xi\theta
=\partial_{\eta\eta}\theta+\beta^2\partial_{ss}\theta,
\qquad
\partial_\eta\theta(\xi,0)=-1,\quad
\partial_\eta\theta(\xi,1)=0,\quad
\partial_s\theta|_{s=0,1}=0 .
$$

La expansión usa cosenos en altura y cosenos pares en ancho por simetría del calentamiento y del flujo base. La matriz de masa se integra con los momentos analíticos del perfil de Poiseuille y la de difusión es diagonal. En los modos generalizados, el modo constante entrega el balance exacto $T_b-T_{\rm in}=q''Wx/(\dot m c_p)$. Los modos no constantes dan la diferencia entre la media de $T_w$ en ancho y la mezcla $T_b$. Su promedio axial da $\Delta T_A$ y $h=q''/\Delta T_A$. La suma modal usa como levantamiento el límite desarrollado obtenido por expansión de Poisson. Para $H/W=0.1$, el código da $Nu_{D_h}=4.55398$, frente a 4.558 en la tabla 3, columna 1L, de Spiga y Morini, una diferencia de 0.088 %. Para $H/W=0.05$ el valor calculado es 4.73958. [Spiga y Morini, H2 de una pared ancha](https://doi.org/10.1016/0017-9310(95)00205-7).

La tabla usa $q''=100$ W/m², $W=0.300$ m, $H=0.015$ m, $L=0.300$ m, $T_{\rm in}=300$ K y una distancia entre tomas de 0.420 m. La referencia térmica omite conducción axial en el fluido y no incluye la placa. Para una verificación exacta de ese problema, usar flujo en la pared mojada y difusión solo transversal en el solver. Si el solver solo admite conducción isotrópica, comparar también las estaciones interiores y documentar el efecto de los bordes térmicos y el flujo difusivo axial. Usar la campaña CHT para el colector, con temperatura de pared y $h$ definidos en la interfaz interna.

| $Re_{\rm ref}$ | $\Delta p$ exacta, Pa | $h$ Graetz 3D, W/(m²·K) | $T_{b,\rm out}$, K |
|---:|---:|---:|---:|
| 75 | 0.0175780 | 4.90524 | 341.027 |
| 100 | 0.0234374 | 5.00489 | 330.770 |
| 125 | 0.0292967 | 5.10449 | 324.616 |
| 150 | 0.0351561 | 5.20436 | 320.514 |
| 200 | 0.0468747 | 5.40321 | 315.385 |
| 400 | 0.0937495 | 6.13550 | 307.693 |
| 800 | 0.1874990 | 7.26715 | 303.846 |
| 1200 | 0.2812485 | 8.12759 | 302.564 |

La diferencia entre 26×26 y 40×40 modos es de 0.00136–0.00249 % para $Re_{\rm ref}=75$–150 y llega a 0.0207 % para 1200. Un cálculo adicional con 54×54 modos dio $h=5.00487359$ y 8.12730107 W/(m²·K) a 100 y 1200, respectivamente. Esas diferencias miden sensibilidad modal en el problema de referencia. A igual Reynolds, el ancho finito modifica la solución de manera apreciable respecto a placas paralelas. Por ejemplo, a 100 el Graetz 3D da 5.00489 frente a 5.05797 W/(m²·K) en el caso 2D.

## Comparaciones, errores y simetría

- Informar errores firmados $100(\phi_{\rm CFD}/\phi_{\rm ref}-1)$ para $\Delta p,h,Nu$, siempre con la misma longitud de medición y definición de diámetro. Para $T_b$, comparar el incremento respecto a $T_{\rm in}$ o la diferencia absoluta en kelvin. Comparar también la norma seccional $\|u_x-u_{\rm ref}\|_{L^2(S)}/(U\sqrt{|S|})$ y el valor de velocidad central. En convección forzada plana, el perfil de Poiseuille exige $u_y=u_z=0$.
- Cerrar masa con flujos de caras y energía con flujo entálpico, flujo difusivo por entrada/salida si corresponde, pérdidas y cambio de almacenamiento. Para una mejora subporcentual de $h$, evaluar el cociente ondulado/plano con refinamientos homólogos y exigir que las sensibilidades espaciales y algebraicas sean menores que la mejora. Los balances integrales y la concordancia del plano evalúan verificaciones distintas. Un saldo de masa o energía pequeño puede coexistir con errores locales.
- En un ducto completo con condiciones simétricas, usar la reflexión $R(x,y,z)=(x,y,W-z)$. Calcular $\|g-g\circ R\|_2/(\sqrt{V}g_{\rm esc})$ para $g\in(u_x,u_y,T,p)$. Para la velocidad lateral, usar $\|u_z+u_z\circ R\|_2/(U\sqrt V)$. Escalas útiles son $U$, $q''H/k$ y $\rho U^2$. Evaluar por separado $\|u_z\|_2/(U\sqrt V)$ y la vorticidad axial $\omega_x=\partial_y u_z-\partial_z u_y$. Un patrón simétrico de vórtices puede dar un error de reflexión muy pequeño y una velocidad lateral apreciable.
- Una mitad del ancho con condición de simetría permite comprobar la rama simétrica estacionaria y ahorrar costo. Para evaluar modos transversales y pérdida de simetría, emplear el ancho completo, conservar las paredes laterales con no deslizamiento y sembrar perturbaciones con componentes pares e impares. Colocar sondas cerca de ambos laterales, en los cuartos del ancho y en el centro, además de su distribución axial. En calentamiento desde abajo, comparar el caso de gravedad nula y el de flotación a igual caudal. Los umbrales publicados con dos paredes isotermas pertenecen a condiciones térmicas distintas del absorbedor a flujo impuesto con techo adiabático. [Estabilidad tridimensional con paredes laterales](https://doi.org/10.1016/S0017-9310(99)00099-X).
