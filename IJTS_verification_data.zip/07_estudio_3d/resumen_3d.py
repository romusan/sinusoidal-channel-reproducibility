"""Build comparable 2D–3D tables, mesh sensitivity estimates and figures."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq

from energia_q1 import locate
from medir_su2 import fields, load_meta
from su2_caso import RHO


HERE = Path(__file__).resolve().parent
FIG = HERE / "figuras"
STAGES = {"campana": "media", "refinadas": "fina", "gruesas": "gruesa", "ventana": "media"}


def archived_results():
    rows = []
    for folder, grid in STAGES.items():
        for path in sorted((HERE / "corridas" / folder).glob("*/metricas_q1.json")):
            d = json.loads(path.read_text(encoding="utf-8"))
            row = d["metrics"]
            if row["estabilizacion_Q1"] != .5 or not d["signature"][-1]:
                continue
            row.update(malla=grid, carpeta=folder)
            row["estado_balance"] = ("aceptable" if
                abs(row["error_masa_rel"]) < .005 and
                row["max_error_flujo_seccional_rel"] < .015 and
                abs(row["cierre_energia_rel"]) < 1e-6 and
                row["T_aire_min_K"] >= 299.965 and
                row["T_aire_max_K"] <= row["T_placa_max_K"] + .03
                else "revisar campo o balance")
            rows.append(row)
    return pd.DataFrame(rows)


def compare(data):
    keys = ["H_mm", "malla", "Re_ref_objetivo"]
    vals = ["h_W_m2K", "dp_Pa", "Q_aire_W", "area_real_m2", "estado_balance"]
    flat = data[data.A_mm.eq(0)][keys + vals]
    pairs = data[data.A_mm.gt(0)].merge(flat, on=keys, suffixes=("", "_plano"))
    for c in vals[:4]:
        pairs[f"ratio_{c}"] = pairs[c] / pairs[f"{c}_plano"]
    pairs["ratio_hA"] = pairs["ratio_h_W_m2K"] * pairs["ratio_area_real_m2"]
    d2 = pd.read_csv(HERE.parent / "05_resultados" / "resultados_malla_fina.csv")
    d2 = d2.rename(columns={"Re_ref": "Re_ref_objetivo"})
    map_keys = ["H_mm", "A_mm", "lambda_mm", "Re_ref_objetivo"]
    cols = ["ratio_h_W_m2K", "ratio_dp_Pa", "h_W_m2K", "dp_Pa"]
    return pairs.merge(d2[map_keys+cols].rename(columns={k:f"{k}_2d" for k in cols}),
                       on=map_keys, how="left")


def refine(pairs):
    sensitivity_path = HERE/"sensibilidad_estabilizacion_3d.csv"
    alternative = pd.read_csv(sensitivity_path) if sensitivity_path.is_file() else pd.DataFrame()
    scheme_ratio = {}
    if len(alternative) == 3 and alternative.A_mm.eq(0).sum() == 1:
        flat = alternative.loc[alternative.A_mm.eq(0),"h_W_m2K"].iloc[0]
        scheme_ratio = dict(zip(alternative.caso, alternative.h_W_m2K/flat))
    rows = []
    for (case, re), group in pairs.groupby(["caso", "Re_ref_objetivo"]):
        g = group.set_index("malla")
        if set(g.index) != {"gruesa", "media", "fina"}:
            continue
        row = {"caso": case, "Re_ref": re}
        for key in ("ratio_h_W_m2K", "ratio_dp_Pa"):
            a = g[key]
            spread = 1.25 * (a.max() - a.min())
            row.update({f"{key}_{l}": a[l] for l in ("gruesa", "media", "fina")})
            row[f"U_{key}"] = spread
        scheme = (abs(scheme_ratio[case] - row["ratio_h_W_m2K_media"])
                  if case in scheme_ratio and re == 100 else np.nan)
        row["U_h_estabilizacion"] = scheme
        row["U_h_combinada"] = row["U_ratio_h_W_m2K"] + (scheme if np.isfinite(scheme) else 0.)
        row["mejora_h_resuelta"] = bool(
            row["ratio_h_W_m2K_fina"] > 1 + row["U_h_combinada"] and
            g.estado_balance.eq("aceptable").all() and g.estado_balance_plano.eq("aceptable").all())
        rows.append(row)
    return pd.DataFrame(rows)


def pumping(data):
    rows = []
    medium = data[data.malla.eq("media") & data.Re_ref_objetivo.between(75,125)]
    for height, block in medium.groupby("H_mm"):
        flat = block[block.A_mm.eq(0) & block.Re_ref_objetivo.eq(100)]
        if len(flat) != 1:
            continue
        target = flat.iloc[0]
        per_re = target.mass_in_kg_s / (RHO * 100)
        for name, g in block[block.A_mm.gt(0)].groupby("caso"):
            if len(g) < 3:
                continue
            g = g.sort_values("Re_ref_objetivo")
            p = PchipInterpolator(g.Re_ref_objetivo, g.dp_completa_Pa)
            lo, hi = g.Re_ref_objetivo.iloc[[0,-1]]
            wanted = target.bomba_W
            residual = lambda re: p(re)*re*per_re-wanted
            if residual(lo) * residual(hi) > 0:
                continue
            re = brentq(residual, lo, hi)
            h = PchipInterpolator(g.Re_ref_objetivo, g.h_W_m2K)(re)
            q = PchipInterpolator(g.Re_ref_objetivo, g.Q_aire_W)(re)
            rows.append(dict(caso=name, H_mm=height, potencia_W=wanted, Re_plano=100.,
                             Re_ondulado=re, h_ratio=float(h/target.h_W_m2K),
                             q_ratio=float(q/target.Q_aire_W), cierre_rel=float(residual(re)/wanted)))
    return pd.DataFrame(rows)


def plot_pairs(pairs):
    selected = pairs[pairs.malla.eq("media") & pairs.Re_ref_objetivo.isin([100, 800])]
    cases = list(dict.fromkeys(selected.caso))
    fig, ax = plt.subplots(2, 1, figsize=(8.6, 6.3), sharex=True, layout="constrained")
    xx = np.arange(len(cases))
    colors = ["#007e82", "#b04f32"]
    for j, re in enumerate([100, 800]):
        d = selected[selected.Re_ref_objetivo.eq(re)].set_index("caso").reindex(cases)
        offset = .18*(2*j-1)
        for a, col, label in zip(ax, ["ratio_h_W_m2K", "ratio_dp_Pa"],
                                 ["Cambio de h frente a plana (%)", "Cambio de Δp frente a plana (%)"]):
            bars = a.bar(xx + offset, 100*(d[col]-1), width=.32, color=colors[j], label=f"3D, Re={re}")
            invalid = ~(d.estado_balance.eq("aceptable") & d.estado_balance_plano.eq("aceptable"))
            for bar, flag in zip(bars,invalid):
                if flag:
                    bar.set_hatch("///")
                    bar.set_edgecolor("#26384a")
            if f"{col}_2d" in d:
                a.plot(xx+offset, 100*(d[f"{col}_2d"]-1), linestyle="none",
                       marker="o", markersize=3, color="#192934")
            a.set_ylabel(label)
            a.axhline(0, lw=.7, color="#3f4b55")
            a.grid(axis="y", alpha=.21)
    ax[0].plot([], [], "o", color="#192934", ms=3, label="2D del estudio anterior")
    ax[0].legend(frameon=False, ncol=3, fontsize=8)
    ax[1].set_xticks(xx, [k.replace("_"," / ") for k in cases], rotation=24, ha="right")
    fig.savefig(FIG / "comparacion_2d_3d.png", dpi=240)
    plt.close(fig)


def plot_cross(data):
    candidate = data[data.caso.eq("H15_A150_L30") & data.malla.eq("media")].sort_values("Re_ref_objetivo")
    if candidate.empty:
        return
    r = candidate.iloc[-1]
    path = HERE/"corridas"/r.carpeta/r.corrida
    meta = load_meta(path)
    grid = np.load(locate(meta))
    temp = np.load(path/"termico_3d_q1.npz")["air_temperature_K"].reshape(grid["air_ids"].shape)
    flow = fields(path/"restart_air.csv").sort_values("pointid")
    wz = flow.velocityz.to_numpy().reshape(temp.shape)
    x, y, z = grid["x"], grid["y_air"], grid["z"]
    j = np.abs(x-.146).argmin()
    xx, yy = np.meshgrid(z*1e3, y[j]*1e3)
    fig, ax = plt.subplots(2, 1, figsize=(8, 4.8), sharex=True, layout="constrained")
    im = ax[0].pcolormesh(xx, yy, temp[j], cmap="inferno", shading="gouraud")
    fig.colorbar(im, ax=ax[0], label="T del aire (K)")
    w = wz[j] / meta["U_m_s"] * 100
    im = ax[1].pcolormesh(xx, yy, w, cmap="RdBu_r", vmin=-np.abs(w).max(),
                          vmax=np.abs(w).max(), shading="gouraud")
    fig.colorbar(im, ax=ax[1], label="Velocidad lateral (% de U)")
    ax[0].set_title(f"H15 / A1,50 / λ30, Re={r.Re_ref_objetivo:g}, corte x={x[j]*1e3:.1f} mm")
    for a in ax:
        a.set_ylabel("Altura y (mm)")
    ax[1].set_xlabel("Ancho z (mm)")
    fig.savefig(FIG/"campo_seccional_3d.png", dpi=240)
    plt.close(fig)


def plot_geometry():
    spec = json.loads((HERE/"mallas/campana/H15_A150_L60.json").read_text(encoding="utf-8"))
    g = {k: v*1000 for k,v in spec["dimensiones_m"].items()}
    x = np.linspace(-g["L_entrada"], g["L"]+g["L_salida"], 241)
    z = np.linspace(0,g["W"], 25)
    active = (x >= 0) & (x <= g["L"])
    floor = np.where(active,g["A"]*np.sin(2*np.pi*x/g["lambda"]),0.)
    X,Z = np.meshgrid(x,z)
    Y = np.broadcast_to(floor,X.shape)
    fig = plt.figure(figsize=(8.1, 3.45), layout="constrained")
    ax = fig.add_subplot(projection="3d")
    ax.plot_surface(X,Z,Y,color="#9facc1", alpha=.5, linewidth=0)
    ax.plot_surface(X[:,active],Z[:,active],Y[:,active]-g["espesor"],color="#743a28",linewidth=0)
    ax.plot_surface(X[:,active],Z[:,active],Y[:,active],color="#c96343", linewidth=0)
    ax.plot_surface(X,Z,np.full_like(X,g["H"]),color="#62979c",alpha=.22, linewidth=0)
    for zz in (0,g["W"]):
        ax.plot(x,np.zeros_like(x)+zz,floor,color="#35445b",lw=.7)
        ax.plot(x,np.zeros_like(x)+zz,np.zeros_like(x)+g["H"],color="#355664",lw=.7)
    for xx in (x[0],x[-1]):
        for zz in (0,g["W"]):
            ax.plot([xx,xx],[zz,zz],[0,g["H"]],color="#35445b",lw=.7)
    ax.set(xlabel="Flujo x (mm)",ylabel="Ancho z (mm)",zlabel="Altura y (mm)")
    ax.set_box_aspect((3.4,2.,.67))
    ax.view_init(elev=24,azim=-66)
    ax.set_title("Dominio del panel H15 / A1,50 / λ60",fontsize=10)
    fig.savefig(FIG/"panel_parametrico_3d.png",dpi=230)
    plt.close(fig)


def transient_table():
    rows = []
    fig, ax = plt.subplots(figsize=(7.2,3.6), layout="constrained")
    for p in sorted((HERE/"transitorios").glob("*/perturbacion.csv")):
        d = pd.read_csv(p)
        meta = json.loads((p.parent/"transient.json").read_text(encoding="utf-8"))
        start = d.rms_U.iloc[0]
        if not start > 0:
            continue
        end = d.rms_U.iloc[-1]
        rows.append(dict(corrida=p.parent.name, **meta, RMS_inicial=start, RMS_final=end,
                         ratio_final_inicial=end/start, n_campos=len(d)))
        ax.semilogy(d.t_transitos,d.rms_U, marker=".", ms=3, lw=1, label=p.parent.name)
    if rows:
        ax.grid(alpha=.22)
        ax.set(xlabel="Tiempos de tránsito", ylabel="RMS de perturbación / U")
        ax.legend(frameon=False, fontsize=8)
        fig.savefig(FIG/"decaimiento_3d.png",dpi=240)
    plt.close(fig)
    return pd.DataFrame(rows)


def main():
    FIG.mkdir(exist_ok=True)
    data = archived_results()
    pairs = compare(data)
    outputs = {
        "resultados_3d": data, "comparacion_pareada_3d": pairs,
        "refinamiento_3d": refine(pairs), "igual_potencia_3d": pumping(data),
        "transitorios_3d": transient_table(),
    }
    for filename, table in outputs.items():
        if not table.empty:
            table.to_csv(HERE/f"{filename}.csv", index=False, encoding="utf-8-sig")
    plot_pairs(pairs)
    plot_cross(data)
    plot_geometry()
    print(f"{len(data)} soluciones CHT; {len(pairs)} comparaciones frente a plana")


if __name__ == "__main__":
    main()
