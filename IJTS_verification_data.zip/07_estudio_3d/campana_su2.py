"""Run a Cartesian product of meshes and Reynolds numbers with bounded parallelism."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
from time import perf_counter


HERE = Path(__file__).resolve().parent


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--grid", type=Path, required=True)
    cli.add_argument("--cases", nargs="+")
    cli.add_argument("--re", type=float, nargs="+", required=True)
    cli.add_argument("--output", type=Path, required=True)
    cli.add_argument("--workers", type=int, default=3)
    cli.add_argument("--iterations", type=int, default=550)
    cli.add_argument("--cfl", type=float, default=40.)
    cli.add_argument("--cht", action="store_true")
    cli.add_argument("--inner", type=int, default=2)
    cli.add_argument("--solid-inner", type=int, default=4)
    cli.add_argument("--from-re", type=float)
    cli.add_argument("--from-directory", type=Path)
    args = cli.parse_args()
    grids = [p for p in sorted(args.grid.glob("*.su2")) if not args.cases or p.stem in args.cases]
    if not grids:
        raise SystemExit("No matching meshes")

    def run(case):
        mesh, re = case
        folder = args.output / f"{mesh.stem}_Re{re:g}"
        mode = [] if args.cht else ["--fluid-only", "--cold"]
        cmd = [
            sys.executable, str(HERE / "su2_caso.py"), "--mesh", str(mesh),
            "--out", str(folder), "--re", str(re), "--iterations", str(args.iterations),
            "--threads", "1", "--cfl", str(args.cfl), "--inner", str(args.inner),
            "--solid-inner", str(args.solid_inner), *mode,
        ]
        if args.from_re is not None:
            base = (args.from_directory or args.output) / f"{mesh.stem}_Re{args.from_re:g}"
            cmd += ["--restart", str(base), "--restart-scale"]
        start = perf_counter()
        result = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        print(f"{mesh.stem} Re={re:g} code={result.returncode} {perf_counter()-start:.1f} s",
              flush=True)
        if result.returncode:
            print(result.stdout, flush=True)
        return result.returncode

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(run, [(mesh, re) for re in args.re for mesh in grids]))
    if any(results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
