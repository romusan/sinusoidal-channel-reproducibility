# Contraste de Reynolds a longitud de onda fija

Se compara la misma pareja plana–ondulada a Re₀ = 100 y 800. La onda tiene A = 1,50 mm y λ = 60 mm. Se mantienen las coordenadas y la conectividad de las tres mallas de cada geometría, la forma normalizada de la entrada, la potencia de 9 W y las tomas estáticas. Los archivos de malla de momento coinciden byte a byte a los dos Reynolds y la velocidad de entrada se multiplica por ocho. Se vuelve a resolver el campo térmico con la corrección acotada, σ = 0. A Re₀ = 800 se usan los controles de momento de la campaña en malla media y se resuelven los controles de las otras dos mallas y las seis corridas periódicas.

| Malla | Celdas de aire | Δh sólido a 100 | Δh periódico a 100 | Δh sólido a 800 | Δh periódico a 800 | Δp sólido a 800 | Δp periódico a 800 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Gruesa | 3.600 | +0,233 % | +0,276 % | −0,935 % | −0,472 % | +11,772 % | +12,063 % |
| Media | 16.128 | +0,464 % | +0,485 % | −1,174 % | −0,883 % | +9,533 % | +9,700 % |
| Fina | 42.768 | +0,429 % | +0,451 % | −1,801 % | −1,817 % | +9,075 % | +9,121 % |

Cada porcentaje compara el ondulado con el plano a la misma malla, Reynolds y contorno. En malla fina, la diferencia de la respuesta de h entre Re₀ = 800 y 100 es −2,230 puntos porcentuales con laterales sólidos y −2,267 con periodicidad. El margen descriptivo de sensibilidad se calcula como 1,25 veces el rango de las diferencias en las tres mallas más el mayor cambio al aplicar la variante térmica en ambos Reynolds en las mallas media y fina. Los márgenes respectivos son 2,428 y 3,344 puntos y contienen los dos contrastes. Con la variante en ambos Reynolds, los contrastes son −1,975 y −2,033 puntos en malla fina. En malla media periódica el contraste con el stencil ampliado es +0,077 puntos. La magnitud del contraste lateral en h a 800 es 0,016 puntos en malla fina, frente a una sensibilidad de 0,935 puntos al incluir el máximo desplazamiento por corrección entre las mallas media y fina.

La variante térmica de malla media a Re₀ = 800 da −0,140 % en h con laterales sólidos y +0,488 % con periodicidad. En malla fina da −1,620 % y −1,626 %, respectivamente. El cambio en h absoluto al ampliar la corrección va de 15,939 a 18,039 % en malla media y de 8,460 a 9,043 % en la fina. Los doce casos de momento alcanzaron log₁₀ del residuo RMS de presión ≤ −11. La temperatura cumplió las cotas a 10⁻⁶ K y los valores en las caras periódicas coincidieron. La comparación es para la rama estacionaria de convección forzada.

[Resultados por caso](resultados_re800_l60_contornos.csv) · [Comparación por contorno](comparacion_contornos_re800_l60.csv) · [Diferencias entre Reynolds](comparacion_reynolds_l60.csv) · [Sensibilidad en malla media](re800_l60_sensibilidad_acotada.csv) · [Sensibilidad en malla fina](re800_l60_sensibilidad_acotada_fina.csv) · [Caso a Re₀ = 100](prueba_re100_contornos.md)

## Reproducción

Desde la carpeta 07_estudio_3d, usar el entorno de [la campaña 3D](README.md).

~~~powershell
python prueba_re100_contornos.py --re 800 --out resultados_re800_l60_contornos.csv
python prueba_re100_contornos.py --re 800 --mallas media --workers 1 --first-ring --out re800_l60_sensibilidad_acotada.csv
python prueba_re100_contornos.py --re 800 --mallas fina --workers 1 --first-ring --out re800_l60_sensibilidad_acotada_fina.csv
python comparar_contornos_re100.py --re 800 --fine-sensitivity
~~~
