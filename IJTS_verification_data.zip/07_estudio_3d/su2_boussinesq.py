"""Run SU2 coupled 3D CHT with upward physical Y and gravity along solver -Z."""

import argparse
from argparse import Namespace
import hashlib
import json
import os
from pathlib import Path
import subprocess

import numpy as np
import pandas as pd

from energia_q1 import locate
from medir_su2 import load_meta
from su2_caso import CP, options, prepare


def rotate_mesh(path):
    rotated = path.with_name("gravity_mesh.su2")
    with path.open(encoding="ascii") as source, rotated.open("w", encoding="ascii") as dest:
        for line in source:
            dest.write(line)
            if not line.startswith("NPOIN"):
                continue
            n = int(line.split("=")[1].split()[0])
            for _ in range(n):
                x, y, z, *rest = next(source).split()
                dest.write(" ".join([x, f"{-float(z):.16g}", y, *rest]) + "\n")
    return rotated


def convert(frame, gravity):
    if not gravity:
        return frame
    data = frame.copy()
    data["y"], data["z"] = -frame.z, frame.y
    if "Velocity_y" in data:
        data["Velocity_y"], data["Velocity_z"] = -frame.Velocity_z, frame.Velocity_y
    return data


def config_file(path):
    return dict(tuple(v.strip() for v in line.split("=",1))
                for line in path.read_text(encoding="ascii").splitlines() if "=" in line)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("baseline",type=Path)
    cli.add_argument("--out",type=Path,required=True)
    cli.add_argument("--iterations",type=int,default=300)
    cli.add_argument("--gravity",action="store_true")
    cli.add_argument("--su2",type=Path,
                     default=Path(os.environ.get("TEMP","."))/"colector_su2_860/bin/SU2_CFD.exe")
    args = cli.parse_args()
    case = args.baseline
    seed_info = load_meta(case)
    gridfile = locate(seed_info)
    grid = np.load(gridfile)
    temp = np.load(case/"termico_3d_q1.npz")
    directory = args.out.resolve()
    directory.mkdir(parents=True,exist_ok=True)
    seeds = directory/"semilla"
    seeds.mkdir(exist_ok=True)
    fluid = pd.read_csv(case/"restart_air.csv").sort_values("PointID")
    fluid["Enthalpy"] = CP*(temp["air_temperature_K"]-298.15)
    convert(fluid,args.gravity).to_csv(seeds/"restart_air_0.csv",index=False)
    solid = pd.DataFrame(grid["solid_xyz"].reshape(-1,3),columns=["x","y","z"])
    solid.insert(0,"PointID",np.arange(len(solid)))
    solid["Temperature"] = temp["solid_temperature_K"]
    convert(solid,args.gravity).to_csv(seeds/"restart_solid_1.csv",index=False)
    args_config = Namespace(out=directory,mesh=gridfile.with_suffix(".su2"),
                            re=seed_info["Re_ref"],uniform=False,fluid_only=False,cold=False,
                            restart=seeds,restart_scale=False,linear=10,iterations=args.iterations,
                            inner=2,solid_inner=4,cfl=30.)
    work, cfg, meta = prepare(args_config)
    meshfile = directory/"mesh.su2"
    if args.gravity:
        meshfile = rotate_mesh(meshfile)
        inlet = directory/"inlet_0.dat"
        lines = inlet.read_text(encoding="ascii").splitlines()
        values = np.loadtxt(inlet,skiprows=4)
        y = values[:,1].copy()
        values[:,1], values[:,2] = -values[:,2], y
        with inlet.open("w",encoding="ascii") as out:
            out.write("\n".join(lines[:4])+"\n")
            np.savetxt(out,values,fmt="%.16g")
    air_config = config_file(work/"air.cfg")
    main_config = config_file(work/cfg)
    air_config["MESH_FILENAME"] = main_config["MESH_FILENAME"] = meshfile.name
    if args.gravity:
        air_config.update(INC_DENSITY_MODEL="BOUSSINESQ",THERMAL_EXPANSION_COEFF="0.00333333333333333")
    options(work/"air.cfg",air_config)
    options(work/cfg,main_config)
    meta.update(mesh=seed_info["mesh"],mesh_source=seed_info["mesh_source"],
                mesh_sha256=hashlib.sha256(meshfile.read_bytes()).hexdigest(),
                cold=False, out_iter=args.iterations, boussinesq=args.gravity,
                mesh_rotation="x,-z,y" if args.gravity else "")
    (work/"case.json").write_text(json.dumps(meta,indent=2)+"\n",encoding="utf-8")
    with (work/"su2.log").open("w",encoding="utf-8") as log:
        result = subprocess.run([str(args.su2.resolve()),cfg,"-t","1"],cwd=work,
                                env=dict(os.environ,OMP_NUM_THREADS="1"),stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f"SU2 exit {result.returncode}: {work/'su2.log'}")
    print(work)


if __name__=="__main__":
    main()
