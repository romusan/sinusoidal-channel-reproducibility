# Efecto del contorno lateral a Reynolds 800

Se comparan el canal plano y el ondulado de semiamplitud 1,50 mm y longitud de onda 30 mm. Ambos tienen altura media de 15 mm y ancho de 300 mm. Los casos periódicos conservan las coordenadas, la conectividad, el caudal, el perfil de velocidad de entrada, las condiciones de salida y los 9 W de los casos con laterales sólidos. Se mantienen también el diámetro hidráulico de referencia para Re₀ y las tomas de presión en x = −60 mm y x = 360 mm.

En SU2 8.6.0, las caras en z = 0 y z = 300 mm se emparejan por una traslación de 300 mm. Las otras paredes conservan su condición de no deslizamiento. El perfil de entrada se copia byte por byte de su control sólido en cada malla. Ese perfil rectangular sigue impuesto en el caso periódico y puede desarrollar variación transversal aguas abajo. El contraste mide el efecto de la condición lateral para esa entrada común. [Configuración de periodicidad en SU2 8.6.0](https://raw.githubusercontent.com/su2code/SU2/v8.6.0/config_template.cfg)

La energía usa el mismo ensamblaje Q1 y la misma corrección local conservativa de la prueba anterior. Antes de aplicar la corrección se identifican los nodos opuestos de cada plano transversal en el aire y la placa. Si P expande un campo periódico al conjunto completo de nodos, la matriz y la carga reducidas son PᵀAP y Pᵀb. La condensación conserva la potencia aplicada. Se comprueba la igualdad de las temperaturas en ambos lados al expandir el campo y se verifican cotas, residuo y balances con los mismos criterios del control sólido. [Prueba anterior con laterales sólidos](prueba_re800_acotada.md)

Se comprobó el emparejamiento térmico con el banco plano de conducción conjugada, con velocidad cero, techo a 300 K y 100 W/m² en el reverso. La identificación periódica redujo el sistema de 7.137 a 6.588 incógnitas. El campo expandido difirió de la solución analítica por un máximo de 2,02 × 10⁻⁹ K y el flujo calculado por el techo fue 9,00000000030 W.

Para cada contorno, la respuesta de la ondulación se calcula como 100 × (valor ondulado / valor plano − 1), por separado para *h* y para la caída de presión. El efecto lateral sobre esa respuesta es el resultado con paredes sólidas menos el resultado periódico, en puntos porcentuales. El coeficiente *h* sigue referido al área real del absorbedor y a la diferencia pared–mezcla.

## Resultados

| Malla | Celdas de aire | Cambio de *h*, sólido | Cambio de *h*, periódico | Cambio de Δ*p*, sólido | Cambio de Δ*p*, periódico |
| --- | ---: | ---: | ---: | ---: | ---: |
| Gruesa | 7.776 | −4,25 % | −4,09 % | +37,38 % | +38,07 % |
| Media | 26.244 | −5,54 % | −5,48 % | +23,35 % | +23,95 % |
| Fina | 91.854 | −5,74 % | −5,69 % | +17,16 % | +17,19 % |

| Geometría en malla fina | *h* sólido [W/(m² K)] | *h* periódico [W/(m² K)] | Δ*p* sólido [Pa] | Δ*p* periódico [Pa] |
| --- | ---: | ---: | ---: | ---: |
| Plana | 7,0180 | 7,0293 | 0,19013 | 0,17929 |
| Ondulada | 6,6150 | 6,6295 | 0,22276 | 0,21012 |

La ondulación reduce *h* en las tres mallas con ambos contornos. En malla fina, la periodicidad eleva *h* un 0,16 % en el canal plano y un 0,22 % en el ondulado. La reducción de *h* atribuida a la ondulación se atenúa 0,056 puntos porcentuales. En malla media, extender la corrección térmica a los vecinos inmediatos desde la primera pasada da −4,85 % con laterales sólidos y −4,70 % con periodicidad. La atenuación pasa de 0,058 a 0,149 puntos porcentuales, lo que muestra la sensibilidad del tamaño de este efecto a la corrección térmica.

La periodicidad reduce la caída de presión estática en ambas geometrías en las tres mallas. En malla fina las reducciones son del 5,70 % para el plano y del 5,67 % para el ondulado. La penalización relativa de la ondulación sigue siendo positiva y difiere en solo 0,036 puntos porcentuales entre los contornos en malla fina. Esa diferencia cambia 0,560 puntos porcentuales entre la malla media y la fina. La magnitud de la penalización hidráulica todavía muestra sensibilidad al refinamiento.

Las seis corridas periódicas alcanzaron log₁₀ del residuo RMS de presión ≤ −11. Las caras emparejadas registraron coincidencia de presión, velocidad y temperatura. Se cumplieron las cotas térmicas, con un desequilibrio relativo de energía máximo de 7,07 × 10⁻¹² y una desviación máxima de caudal por sección de 0,596 %. El mayor cambio medido de Re₀ a la entrada entre los contornos fue de 0,129. El alcance es la solución 3D estacionaria con convección forzada, la geometría especificada y el perfil común de entrada. [Comparación de contornos](comparacion_contornos_re800.csv) · [Resultados periódicos y controles](resultados_re800_periodicos.csv) · [Variante térmica en malla media](re800_periodico_sensibilidad_acotada.csv)

## Reproducción

Desde la carpeta 07_estudio_3d, usar el mismo entorno y las mismas mallas de la [prueba a Reynolds 800](prueba_re800_acotada.md). Cada instancia de SU2 usa un hilo. El archivo de configuración, el campo, el historial y el control de las caras se guardan en corridas/prueba_re800_periodica.

~~~powershell
python flujo_periodico_re800.py
python energia_acotada.py --periodic --out resultados_re800_periodicos.csv
python energia_acotada.py --periodic --mallas media --first-ring --out re800_periodico_sensibilidad_acotada.csv
python comparar_contornos_re800.py
~~~
