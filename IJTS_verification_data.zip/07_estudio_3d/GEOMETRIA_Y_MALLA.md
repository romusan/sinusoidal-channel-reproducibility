# Canal tridimensional y malla

La geometría usa los nueve casos de [parametros.csv](../02_cad/parametros.csv) y corresponde a las piezas del [ensamblaje de SOLIDWORKS](../02_cad/modelos/Familia/Colector_CHT.SLDASM). El aire ocupa los 300 mm de ancho entre Z = 0 y Z = W, con dos paredes laterales. X es la dirección axial e Y la altura. La entrada está en X = −120 mm y la salida en X = 420 mm. La región calentada ocupa X = 0 a 300 mm. El techo está a Y = H. En la región calentada el piso es Y = A sin(2πX/λ). Los tramos rectos tienen piso a Y = 0. Los extremos del seno coinciden en posición con los tramos rectos y cambian de pendiente. La placa tiene 1 mm de espesor vertical, cubre la región calentada y comparte su cara superior con el aire. El canal completo tiene relaciones W/H de 25, 20 o 15.

La [tabla CAD](../02_cad/modelos/Familia/configuraciones.csv) registra las áreas, separaciones y volúmenes verificados. La malla se genera directamente desde las mismas dimensiones, en metros, mediante una transformación estructurada. Usa un techo plano, malla alineada con ambos extremos de la placa y hexaedros lineales que aproximan el seno por cuerdas en X. Se puede concentrar la malla cerca del piso y techo mediante `--estirar-y` y cerca de las paredes laterales mediante `--estirar-z`. Cada malla incluye dos zonas. Las dos caras de la interfaz tienen la misma discretización y coordenadas con normales opuestas. [Formato multizona SU2](https://su2code.github.io/docs_v7/Multizone/), [caso conjugado de referencia del programa](https://github.com/su2code/TestCases/tree/master/coupled_cht/incomp_2d)

## Superficies

| Zona | Marcador | Ubicación o uso |
|---|---|---|
| Aire | `inlet`, `outlet` | Planos en X = −120 y 420 mm |
| Aire | `roof` | Techo plano |
| Aire | `sidewalls` | Dos paredes en Z = 0 y Z = W |
| Aire | `floor_adiabatic` | Piso de entrada y salida |
| Aire | `interface_air` | Cara aire–placa, con no deslizamiento y acoplamiento térmico |
| Placa | `interface_solid` | Cara placa–aire |
| Placa | `solid_adiabatic` | Cuatro cantos de la placa |
| Placa | `flux_000`, `flux_001`, etc. | Reverso de la placa por franjas axiales con `--franjas-flujo` |
| Placa | `absorbed_flux` | Reverso completo cuando se omite `--franjas-flujo` |

Las superficies de aire se etiquetan para aplicar no deslizamiento en techo, laterales, piso e interfaz. El cálculo de flujo y de energía asigna las condiciones en sus archivos de configuración. Con carga uniforme por área proyectada q″ₚ, cada franja del reverso recibe una potencia integrada de q″ₚ W Δx. A 100 W/m², las potencias de franja suman 9 W en cada caso. El área de cuerda del reverso es igual a la de la interfaz en cada franja porque ambas caras son traslaciones verticales. Si se especifica un flujo por área real, el valor de franja se obtiene dividiendo su potencia entre su área real discretizada.

## Reproducir y revisar

Desde esta carpeta, con Python y NumPy:

```powershell
python generar_malla_su2.py --caso H15_A150_L30 --salida mallas/campana/H15_A150_L30.su2 --nx 80 --ny 7 --nz 16 --ns 2 --franjas-flujo
python verificar_malla_su2.py mallas/campana/H15_A150_L30.su2
```

`--nx` cuenta las celdas del tramo calentado. Cada tramo recto recibe un número proporcional a su longitud. `--ny`, `--nz` y `--ns` cuentan celdas en la altura del aire, el ancho y el espesor de la placa, respectivamente.

| Archivos | Casos | Celdas aire | Celdas placa | nx × ny × nz × ns |
|---|---|---:|---:|---|
| [Piloto](mallas) | H15 plana y H15 A = 1,50 mm, λ = 30 mm | 5 760 | 800 | 40 × 8 × 10 × 2 |
| [Campaña](mallas/campana) | Nueve configuraciones | 16 128 | 2 560 | 80 × 7 × 16 × 2 |
| [Refinadas](mallas/refinadas) | H15 plana y las dos H15 con λ = 60 mm | 42 768 | 7 920 | 120 × 9 × 22 × 3 |

Cada malla lleva un JSON con dimensiones, números de celdas, marcadores, área de cuerda, área del seno, luz mínima y posiciones y áreas de las franjas. El NPZ guarda las coordenadas estructuradas `air_xyz[i,j,k,:]` y `solid_xyz[i,j,k,:]` en orden X–Y–Z y sus identificadores de nodo SU2, que empiezan en cero por zona. `heated_i` enumera los índices axiales de los planos desde X = 0 hasta X = L, inclusive. Sirven para integrar presión, caudal y temperatura de mezcla en planos físicos coincidentes al leer los resultados de SU2.

El verificador comprueba la incidencia de caras, la cobertura completa y no duplicada del contorno, las normales salientes, los Jacobianos positivos en los ocho vértices de cada hexaedro, la coincidencia de la interfaz y el orden nodal del NPZ. Los 14 archivos pasaron estas pruebas. La diferencia máxima de área poligonal de interfaz frente al seno fue 0,433 % en piloto, 0,118 % en campaña y 0,00347 % en las refinadas de λ = 60 mm. [Registro de verificación](verificacion_mallas.jsonl)

Los tres tamaños permiten examinar sensibilidad. Las secuencias tienen distintos factores de cambio en X, Y, Z y espesor. Una estimación formal de orden y GCI requiere una familia de refinamiento diseñada para ese fin.

## Entorno de cálculo

- WSL figura como ejecutable, pero la consulta de distribuciones devolvió el texto de ayuda y código 1. Las funciones opcionales `Microsoft-Windows-Subsystem-Linux` y `VirtualMachinePlatform` registraron estado 2, que indica que están deshabilitadas. [Documentación de Win32_OptionalFeature](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-optionalfeature)
- Las consultas en PATH, directorios de programas y registro de desinstalación no localizaron OpenFOAM, Fluent/ANSYS, COMSOL, Elmer, Simcenter ni Docker. BlueCFD proporciona OpenFOAM 12 para Windows mediante un instalador de 1173 MiB. [Distribución de blueCFD-Core](https://bluecfd.github.io/Core/Downloads/)
- SOLIDWORKS Flow Simulation 2025 SP05 está instalado. Se verificaron `FW03.dll`, `EFDApiSrv.exe` y `efdsolver.exe`. El intento previo de carga COM devolvió `RPC_E_SERVERFAULT`, por lo que la disponibilidad efectiva de la licencia quedó sin confirmar. La activación desde Herramientas → Complementos se puede verificar en una sesión gráfica. [Carga de complementos de SOLIDWORKS](https://help.solidworks.com/2025/english/SolidWorks/sldworks/t_add_ins.htm)
- SU2 ofrece un paquete oficial Windows x64 con OpenMP para v8.6.0, con soporte para flujos incompresibles y transferencia conjugada. Su ejecución y las configuraciones del caso se registran en los resultados del estudio 3D. [SU2 v8.6.0](https://github.com/su2code/SU2/releases/tag/v8.6.0), [guía de transferencia conjugada](https://su2code.github.io/docs_v7/Setup-Guide-Heat-Transfer-CHT/)
